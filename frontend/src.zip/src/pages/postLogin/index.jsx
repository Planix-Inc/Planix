import { useLocation } from 'react-router-dom';
import './postLogin.css';

const PostLogin = () => {
  const location = useLocation();
  const usuario = location.state?.usuario;

  return (
    <div className="bienvenida-container">
      <h1>¡Bienvenido, {usuario}!</h1>

      {usuario === "Profesional" && (
        <p>Te mostramos proyectos para trabajar como profesional.</p>
      )}
      {usuario === "Inversionista" && (
        <p>Revisá ideas para invertir en el mundo de la construcción.</p>
      )}
      {usuario === "Proveedor" && (
        <p>Acá podés publicar tus productos y llegar a más clientes.</p>
      )}
      {usuario === "Constructora" && (
        <p>Sumate a licitaciones activas y conectá con profesionales.</p>
      )}
      {usuario === "Usuario" && (
        <p>Explorá todo lo que ofrece la plataforma y descubrí nuevos proyectos.</p>
      )}
    </div>
  );
};

export default PostLogin;
