import "./Buscador.css";

const Buscador = () => {
    return(
        <h1></h1>
    )
}